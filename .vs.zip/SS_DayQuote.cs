﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockLoadTest
{
    internal class SS_DayQuote
    {
        public decimal c { get; set; }
        public decimal h { get; set; }
        public decimal l { get; set; }
        public decimal o { get; set; }
        public decimal v { get; set; }
        public decimal vw { get; set; }
    }
}
