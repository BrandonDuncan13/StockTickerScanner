﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockLoadTest
{
    internal class SS_LastQuote
    {
        public decimal P { get; set; }
        public int S { get; set; }
        public decimal p { get; set; }
        public int s { get; set; }
        public long t { get; set; }
    }
}
