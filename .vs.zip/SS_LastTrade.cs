﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockLoadTest
{
    internal class SS_LastTrade
    {
        public string? T { get; set; }
        public string? i { get; set; }
        public decimal p { get; set; }
        public int s { get; set; }
        public long t { get; set; }
        public int x { get; set; }
        /// <summary>
        /// Time Stamp
        /// </summary>
        public int y { get; set; }

    }
}
